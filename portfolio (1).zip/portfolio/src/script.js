$(document).ready(function() {
                  });
//this will make it run once page DOM is ready 
 